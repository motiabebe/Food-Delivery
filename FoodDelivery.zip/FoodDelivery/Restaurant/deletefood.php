<?php include('session.php');


if(isset($_POST['delete'])) {
   
    $id = $_POST['id'];

    $delete = "DELETE FROM foods WHERE food_id = '$id'";
    $result = mysqli_query($conn, $delete);
    if($result == true) {
        header('Location: Dashboard.php');
    } else {
        echo '<script>alert("Error deleting food")</script>';
    }
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include('css_linker.php'); ?>
<?php include('navbar.php') ?>    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Delete</title>
</head>
<body>
<?php
            if(isset($_GET['id'])){
                $id = $_GET['id'];
                $sql = "SELECT * FROM foods";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_assoc($result)) {
                    if($row['food_id'] == $id) {
                        $food_id = $row['food_id'];
                        $food_name = $row['name'];
                        $food_image = $row['image'];
                    }
                }
            }
        ?>

    <main class="center">
        <h2>Delete Food</h2>
        <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo $food_id ?>">
            <img src="../assets/<?php echo $food_name ?>" alt="" height="50px" height="50px">
            <h2><?php echo $food_name ?></h2>
            <p>Do you want to delete <?php echo $food_name ?></p>
            <button class="btn bg-black round" name="delete">Delete</button>
        </form>
    </main>
</body>
</html>
