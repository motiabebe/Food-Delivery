<?php include('session.php')?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include('css_linker.php'); ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Food</title>
</head>
<body>
<?php
$msg = "";
            if(isset($_GET['id'])){
                $food_id = $_GET['id'];
                $sql = "SELECT * FROM foods WHERE food_id ='$food_id'";

                $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
                while($row = mysqli_fetch_assoc($result)) {
                       $food_id_show = $row['food_id'];
                       $food_name_show = $row['name'];
                       $food_price_show = $row['price'];
                       $food_type_show = $row['type'];
                       $food_description_show = $row['description'];
                       $food_picture_show = $row['image'];
                }
            }
        ?>

<?php
// include('../backend/db.php');
if(isset($_POST['update'])) {
        $food_name = $_POST['food_name'];
        $food_price = $_POST['food_price'];
        $food_type = $_POST['food_type'];
        $logo = $_FILES['logo']['name'];
        $logo_temp= $_FILES['logo']['tmp_name'];
        $logo_path = "../assets/img/";
        $food_description = $_POST['food_description'];        
        $change = "UPDATE foods SET 
                name = '$food_name',
                price = '$food_price',
                type = '$food_type',
                image = '$logo',
                description = '$food_description' WHERE food_id = $food_id_show";
            move_uploaded_file($logo_temp, $logo_path.$logo);
            mysqli_query($conn,$change) or die(mysqli_error($conn));
    }

        

?>








        <!-- <?php include('css_linker.php'); ?>

         get restaurant id from url and display restaurant details -->
        
    <main class="dash-main">
    <table style="width: 100%;"> <th><h2>Uppdate Products</h2></th><th><?php include('navbar.php') ?></th></table>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="grid grid-center">
                    <input type="hidden" name="id" value="<?php echo$food_id_show ?>">
                    <img src="../assets/img/<?php echo$food_picture_show ?>" alt="" class="img-small img-circle">
                    <label for="">Name: </label>
                    <input type="text" name="food_name" id="" value="<?php echo$food_name_show ?>" required>
                    <!-- <label for="">Address: </label>
                    <input type="text" name="address" id="" value="<?php echo$food_address ?>" required> -->
                    <label for="">Price: </label>
                    <input type="text" name="food_price" id="" value="<?php echo$food_price_show ?>" required>
                    <label for="">Type: </label>
                    <input type="text" name="food_type" id="" value="<?php echo$food_type_show ?>" required>
                    <label>Food description</label>
                    <input type="text=area" rows = "10" cols = "50"  width = "300" height = "100" name="food_description" id="" value="<?php echo$food_description_show ?>"> 
                    <label for="">File: </label>
                    <input type="file" name="logo" id="" required>
                    <button class="btn bg-black round" name="update">Update</button>
                    <br><a href="owner_home.php">back to home</a>
                </div>
                

        </form>
    </main>

    <?php echo $msg ?>
</body>
</html>
