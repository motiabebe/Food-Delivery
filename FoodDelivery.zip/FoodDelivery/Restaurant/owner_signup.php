<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>



    <?php   
        session_start();
        include('food_db.php');
        //include('navbar.php');
            $error_msg_username="";
            $error_msg_password="";
            $error_msg_email="";
            $error_msg_rest_name="";
            $error_msg_rest_address="";
            $msg="";
            $username=$password=$email="";
            $temp_ph="";
            $perm_ph="";


    if(isset($_POST['submit'])) 
        {
            
            

            if(empty($_POST['o_username']))
            {
                $error_msg_username = "Name is empty bruh";
            }
            else if (is_numeric($_POST['o_username']))
            {
                $error_msg_username="Name has numerics";
            }
            else 
            {
                $username=$_POST["o_username"];
                
            }
            if(empty($_POST['o_password']))
            {
                $error_msg_password="password?";
            }
            else 
            {
                $password=$_POST["o_password"];
            }
           
            if(empty($_POST['o_email']))
            {
                $error_msg_email="email?";
            }
            else 
            {
                $email=$_POST["o_email"];
            }



            if(empty($_POST['restaurant_name']))
            {
                $error_msg_rest_name="name?";
            }
            else 
            {
                $restaurant_name=$_POST["restaurant_name"];
            }




            if(empty($_POST['restaurant_address']))
            {
                $error_msg_rest_address="address?";
            }
            else 
            {
                $restaurant_address=$_POST["restaurant_address"];
            }


                





            // if(empty($_FILES["ph_upload"]["name"]))
            // {
            //     $error_msg_file="Choose a jpeg file";
            // }
            // else
            // {
            //     $temp_ph = $_FILES["ph_upload"]["tmp_name"];
            //     $perm_ph = "C:\wamp64\www\PHP\UP_PH\\".$_FILES["ph_upload"]["name"];
                
            // }
            
            //  if all the fields are filled, then the form is submitted
        if(!empty($_POST['o_username']) && 
        !is_numeric($_POST['o_username']) && 
        !empty($_POST['o_password']) &&
        !empty($_POST['restaurant_address']) &&
        !empty($_POST['restaurant_name'])
        )
        {
        // !empty($_FILES['ph_upload']["name"]) &&
        
        $o_id = $username.$password.$email;
        $query="INSERT INTO restaurant_owner (o_username,o_password,o_email,o_id)
        VALUES
        ('$username','$password','$email','$o_id')";
        mysqli_query($conn,$query);

        $msg = "<a href='owner_login.php'>Back to Login page</a>";
        $restaurant_id = $restaurant_name.$restaurant_address.$o_id;
        $query_r="INSERT INTO restaurants (restaurant_name,restaurant_address,restaurant_owner_id,restaurant_id,)
        VALUES
        ('$restaurant_name','$restaurant_address','$o_id','$restaurant_id')";
        mysqli_query($conn,$query_r);
         }
    }

        
        

    
    ?>




</head>
<body>
<header>
        <!-- <?php //include('navbar.php') ?> -->
        <?php include('css_linker.php'); ?>
    </header>

    <main id="sign-pages" class="signup flex flex-row flex-center center">
        <div class="close-button">
                <a href="index">
                    <i class="fa fa-close"></i>
                </a>
            </div>
        <h1>Sign Up</h1>
        <form action="#"  method="POST" name="Form" enctype="multipart/form-data">
            <input type="text" id="inname" placeholder="username" name="o_username" required>
           <br>
            <input type="password" id="inpass" placeholder="password" name="o_password" required>
            <br>
            <input type="text" id="inname" placeholder="example@example.example" name="o_email" required>
            <br>
            <input type="text" id="inname" placeholder="Restaurant name" name="restaurant_name"required>
            <br>
            <input type="text" id="inname" placeholder="address" name="restaurant_address" required>
            <br>
            <!--             
            <h4>Photo</h4>
             <input type="file"  name="ph_upload">
            <p style="color:blue;">
            <?php // echo $error_msg_file; ?>
            </p>  -->
            <button type="submit" class="btn round"   name="submit">Submit</button>
            
        </form>
    </div>



   

    
    
    
    
   
    
</body>
</html>