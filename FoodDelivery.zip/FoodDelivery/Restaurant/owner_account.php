<?php
session_start(); 
include('food_db.php');
if($_SESSION['status'] != "loged_in" )
{
    header("location: owner_login.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>



    




</head>
<body>
<header>
        <!-- <?php //include('navbar.php') ?> -->
        <?php include('css_linker.php'); ?>
    </header>

    <main id="sign-pages" class="signup flex flex-row flex-center center">
        <div class="close-button">
                <a href="index">
                    <i class="fa fa-close"></i>
                </a>
            </div>
        <h1>Update Account</h1>
        <form action="#"  method="POST" name="Form" enctype="multipart/form-data">
        
                        <br><button type="submit" class="btn round"   name="Update_username">Update</button>
    
            <input type="text" id="inname" placeholder="username" name="o_username" value = "<?php echo $_SESSION['o_username'] ?>" required>
            
                        <br><button type="submit" class="btn round"   name="Update_password">Update</button>

            <input type="password" id="inpass" placeholder="password" name="o_password" value = "<?php echo $_SESSION['o_password'] ?>" required>
            
                        <br><button type="submit" class="btn round"   name="Update_email">Update</button>

            <input type="text" id="inname"  name="o_email" value = "<?php echo $_SESSION['o_email'] ?>" required>
            <br><button class="btn round"><a href="owner_home.php">Home</a></button>
        </form>
    </div>

    <?php   
    $username = "";
    $password ="";
    $email ="";     
    if(isset($_POST['Update_username'])) 
    {
        $username=$_POST['o_username'];
        mysqli_query($conn,"UPDATE restaurant_owner set o_username = '$username'");
        header("location:owner_account.php");

    }
    if(isset($_POST['Update_password'])) 
    {
        $password=$_POST['o_password'];
        mysqli_query($conn,"UPDATE restaurant_owner set o_password = '$password'");
        header("location:owner_account.php");
    }
    if(isset($_POST['Update_password'])) 
    {
        $email=$_POST["o_email"]; 
        mysqli_query($conn,"UPDATE restaurant_owner set o_email = '$email'");
        header("location:owner_account.php");
    }
                
                       
          
    ?>

   

    
    
    
    
   
    
</body>
</html>