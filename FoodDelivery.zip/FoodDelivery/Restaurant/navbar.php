<nav>
    <span class="title"></span>
        <ul>
<!--             
            <li><a href="addfood.php"><i></i>
            Add Product
                <i class="fa-solid fa-shop"></i>
                </a>
            </li> -->
            <!-- cart -->
            <li><a href="owner_logout.php"><i></i>
            Logout
                <i class="fa-solid fa-cart-arrow-down"></i> 
                </a>
            </li>
            <!-- <li><a href="owner_relogin.php">
            <i class="fa-solid fa-user-large"></i>
                Update Account<i></i></a>
            </li> -->
        </ul>
</nav>

  
        