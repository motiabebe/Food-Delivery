<?php
session_start();
include('food_db.php');

$msg= ""
?>

<html>
<title>
        login
</title>
   <body>
   <header>
        <?php include('css_linker.php'); ?>
    </header>

    <main id="sign-pages"  class="signin flex flex-center flex-row">
        <div class="close-button">
            <a href="index">
                <i class="fa fa-close"></i>
            </a>
        </div>

        <h1>Re-Sign In</h1>

        <form action="" method="POST" class="center">
            <input type="text" name="username" placeholder="Username" required>
            <br>
            <input type="password" name="password" placeholder="Password" required>
            <br>
            <input type="text" name="email" placeholder="example@example.example" required>
            <br>
            <input class="btn round" value = "Sign in" type="submit" name="login">
            <p>Don't have an account?<pre>  </pre><a href="owner_signup.php">Sign Up</a></p><br>
        <p><?php echo $msg ?></p>
        </form>
        
    </main>


    <?php //include('js_linker.php'); ?>
    <?php //include ('footer.php') ?>
        <?php

if(isset($_POST['login']))
{

    $username = $_POST['username'];
    $password = $_POST['password'];
    $msg;
    $email = $_POST['email'];
    $query = "SELECT * FROM restaurant_owner";
    $result = mysqli_query($conn , $query) or die(mysqli_error($conn));
    
    while($row = mysqli_fetch_assoc($result)) 
        {
            if($row['o_username'] == $username && $row['o_password'] == $password && $row['o_email'] == $email)
                {
                    $_SESSION['o_username'] = $username;
                    $_SESSION['o_password'] = $password;
                    $_SESSION['o_email'] = $email;
                    $o_conid = $_SESSION['o_username'].$_SESSION['o_password'].$_SESSION['o_email'];
                    $_SESSION['o_conid'] = $o_conid;
                    $_SESSION['status'] = "loged_in";
                    header("location:owner_account.php");
                }
            else
            {
                $msg = "access denied";
            }
            
        }
        
    }


?>
   </body>
</html>