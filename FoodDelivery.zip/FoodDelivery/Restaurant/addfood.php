<?php include('session.php');

if(isset($_POST['submit'])) 
    {
        $msg = "<a href='owner_home.php'>Back to home page</a>";
        $food_name = $_POST['food_name'];
        $food_type = $_POST['food_type'];
        $food_price = $_POST['food_price'];
        $food_description = $_POST['food_description'];

        $logo = $_FILES['logo']['name'];
        $logo_temp= $_FILES['logo']['tmp_name'];
        $logo_path = "../assets/img/";
        $query_food ="INSERT INTO foods (name,type,description,price,image,restaurant_id)
        VALUES
        ('$food_name','$food_type','$food_description,'$food_price','$logo','$restaurant_id')";
        mysqli_query($conn,$query_food) or die(mysqli_error($conn));
        move_uploaded_file($logo_temp, $logo_path.$logo);
    }


?>

<html>
    <head>
    <?php include('css_linker.php'); ?>
        <title>
            add
        </title>
    </head>
    <body>
    <?php include('css_linker.php'); ?>
        <!-- <?php //include('navbar.php') ?> -->
        
    
    <table style="width: 100%;"> <th><h2>Add Products</h2></th><th><?php include('navbar.php') ?></th></table>
<main class="dash-main">
        <form method="POST"  enctype="multipart/form-data">
        <div class="grid grid-center">

            <h4>Food name</h4>
            <input type="text" name="food_name" id="">
            <h4>Food type</h4>
            <input type="text" name="food_type" id="">
            <h4>Food price</h4>
            <input type="text" name="food_price" id="">
            <h4>Food description</h4>
            <input type="textarea" row = "10" cols = "50" name="food_description" id="">
            <h4>Photo</h4>
            <label for="">Logo: </label>
                <input type="file" name="logo" id="" required>
                            <button class="btn bg-black round" type="submit"   name="submit" >Add</button>
        </form>
    </main>
    </body>
    
</html>


<?php



?>