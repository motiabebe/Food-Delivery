<?php

include('../backend/db.php');
session_start(); 

if(empty($_SESSION['restaurant_id'])) {
    header('Location: Login.php');
}

$restaurant_id = $_SESSION['restaurant_id'];


$restaurant = $conn->query("SELECT * FROM restaurants where restaurant_id  = '$restaurant_id'");


$foods = $conn->query("SELECT * FROM foods 
INNER JOIN restaurants ON foods.restaurant_id = restaurants.restaurant_id WHERE foods.restaurant_id  = '$restaurant_id'");


?>