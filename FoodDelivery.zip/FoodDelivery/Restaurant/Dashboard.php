<?php include('session.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="color-scheme" content="dark light"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Restaurants </title>
</head>
<body>
    <header>
        
        <?php include('css_linker.php'); ?>
    </header>
    

    <main class="dash-main">
        <table style="width: 100%;"> <th><h2>Viewing Products</h2></th><th><?php include('navbar.php') ?></th></table>
               
        <table class="table" style="width: 100%;">
               
                <tr class="bg-blue">
                    
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Restaurant Name</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>

                <?php foreach($foods as $rows): ?>
                <tr>
                    <th><img src="../assets/img/<?php echo $rows['image'] ?>" alt="" height="100px" width="150px"></th>
                    <th><?php echo $rows['name'] ?></th>
                    <th><?php echo $rows['type'] ?></th>
                    <th><?php echo $rows['restaurant_name'] ?></th>
                    <th><?php echo $rows['price'] ?></th>
                    <th><?php echo $rows['description'] ?></th>
                    <th>
                            <!-- <input type="hidden" name="restaurant_id" value="<?php echo $rows['restaurant_id'] ?>">
                            <button class="btn btn-s bg-white round" name="edit">Edit</button> -->
                            <button class="btn btn-s bg-green round">
                                <i class="fa fa-edit"></i>
                                <a href="editfood.php?id=<?php echo $rows['food_id']; ?>">Edit</a>
                                <i></i>
                            </button>
                    </th>
                    <th>
                        <button class="btn btn-s bg-red round">
                            <i class="fa fa-delete-left"></i>
                            <a href="deletefood.php?id=<?php echo $rows['food_id']; ?>">Delete</a>
                            <i></i>
                        </button>
                    </th>
                </tr>
                <?php endforeach; ?>
            </table>



        </main>
        <!-- <?php include ('js_linker.php') ?> -->
        <br>
        <br>
        <br>
        
</body>
</html>