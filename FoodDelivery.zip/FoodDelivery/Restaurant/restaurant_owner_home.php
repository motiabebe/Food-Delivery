<?php
session_start(); 
include('food_db.php');
if($_SESSION['status'] != "loged_in" )
{
    header("location: owner_login.php");
    
    
}

$_SESSION['o_username'];
$_SESSION['o_password'];
$_SESSION['o_email'];
$_SESSION['o_conid'];
$o_id = $_SESSION['o_conid'];
// echo $o_id ;
// echo $_SESSION['o_username'];
// echo $_SESSION['o_password'];
// echo $_SESSION['o_email'];
// echo $_SESSION['o_conid'];
?>


<html>
    <head>
        <title>
            home
        </title>
        
    </head>
    <body>
        <h1>WELCOME PRODUCER</h1>
        <?php
$query = "SELECT * FROM food WHERE food_owner_id = '$o_id' ";
$result = mysqli_query($conn,$query);
while ($rows = mysqli_fetch_assoc($result))
{
    echo "<br>";
    
    $perm_ph = $rows["food_picture"];

    echo '<table>';
    echo '<tr>';
    echo '<td>';
    echo '<image width = "150px" height = "150px" src = '.'"'.$perm_ph.'">';
    echo '</td>';
    echo '<td>';
    echo $rows["food_name"]."   ";
    echo '</td>';
    echo '<td>';
    echo $rows["food_price"]."   ";
    echo '</td>';
    echo '<td>';
    // echo $rows["food_picture"]."   ";
    echo $rows["food_type"]."   ";
    echo '</td>';
    // echo $rows["food_restaurant_id"]."   ";
     $_SESSION ['food_id'] = $rows["food_id"];
    // echo $rows["food_owner_id"]."   ";
    echo '<td>';
    echo '<form method = "POST">';
    echo '<button name = "delete" >delete</button>';
    if(isset($_POST['delete']))
    {
        header("location: owner_delete.php");
    }
    echo '</form>';
    echo '</td>';
    echo '<td>';
    echo '<form method = "POST">';
    echo '<button name = "edit" >edit</button>';
    if(isset($_POST['edit']))
    {
        header("location: owner_change.php");
    }
    echo '</form>';
    echo '</td>';
    echo '</tr>';
    echo '</table>';
    echo "<br>";
    
}
?>
        <a href="owner_logout.php">logout</a>
        <a href="owner_delete.php">delete a product</a>
        <a href="owner_change.php">change a product in list</a>
        <a href="owner_add.php">add a product to list</a>
        <a href="owner_account.php">my account</a>

    </body>
    
</html>