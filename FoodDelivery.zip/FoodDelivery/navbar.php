<nav>
    <span class="title">Food Delivery</span>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="Browse.php">Browse</a></li>
            <li><a href="SignIn.php">Sign In</a></li>
            <!-- <li><a href="Restaurant/Login.php">Restaurant</a></li> -->
            <li><a href="Delivery/Login.php">Delivery</a></li>
            <li><a href="cPanel.php">cPanel</a></li>
        </ul>
</nav>